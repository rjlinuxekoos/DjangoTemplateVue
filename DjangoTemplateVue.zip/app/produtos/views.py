from django.shortcuts import render, redirect
from django.db import connection, transaction
from django.contrib.auth import authenticate, logout
from django.contrib.auth import login as auth_login
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage
from django.http import JsonResponse
import json


# Create your views here.

def pesquisa(request):
    print("ok")
    context = {}
    context["message"] = "1"
    print(context)
    return render(request, 'teste.html', context)